package com.kevinkda.univ.exam.enterpriseframeworkexam202009;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnterpriseFrameworkExam202009Application {

    public static void main(String[] args) {
        SpringApplication.run(EnterpriseFrameworkExam202009Application.class, args);
    }

}
