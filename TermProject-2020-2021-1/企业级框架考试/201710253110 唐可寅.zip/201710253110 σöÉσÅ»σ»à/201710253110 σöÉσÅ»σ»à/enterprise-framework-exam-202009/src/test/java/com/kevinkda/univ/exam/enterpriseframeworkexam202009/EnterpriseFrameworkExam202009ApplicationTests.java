package com.kevinkda.univ.exam.enterpriseframeworkexam202009;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnterpriseFrameworkExam202009ApplicationTests {

    @Test
    void contextLoads() {
    }

}
