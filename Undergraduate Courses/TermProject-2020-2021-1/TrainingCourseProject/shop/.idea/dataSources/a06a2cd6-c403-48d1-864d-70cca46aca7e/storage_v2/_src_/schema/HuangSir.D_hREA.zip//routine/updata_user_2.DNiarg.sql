create
    definer = cmrhyq@`%` procedure updata_user_2(IN user_ID int, IN userName varchar(32), IN userAge int)
begin
##delete from userTb where userID=user_ID; 
	update userTb set userName=user_Name,userAge=user_Age WHERE userId=user_ID;
end;

