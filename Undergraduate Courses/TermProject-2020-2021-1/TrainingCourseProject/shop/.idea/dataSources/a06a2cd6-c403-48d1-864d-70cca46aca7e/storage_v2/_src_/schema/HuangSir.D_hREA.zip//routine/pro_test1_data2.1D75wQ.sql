create
    definer = cmrhyq@`%` procedure pro_test1_data2(IN carId int, OUT carPrice int)
begin
	select Price into carPrice from test1 where Id=carId;
end;

