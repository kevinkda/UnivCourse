create
    definer = cmrhyq@`%` procedure updata_user(IN user_ID int, IN userName varchar(32))
begin
	update userTb set userName=user_Name;
end;

