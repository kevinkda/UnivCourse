create
    definer = cmrhyq@`%` procedure delete_user(IN user_ID int)
begin
	delete from userTb where userId=user_Id; 
end;

