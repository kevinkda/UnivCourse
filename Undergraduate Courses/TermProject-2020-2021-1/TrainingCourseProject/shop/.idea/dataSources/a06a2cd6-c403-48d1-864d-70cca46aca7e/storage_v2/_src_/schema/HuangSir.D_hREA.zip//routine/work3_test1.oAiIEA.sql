create
    definer = cmrhyq@`%` procedure work3_test1(IN carId int)
begin
	select *,if(Tax is null,Price+0,Price+Tax) as '价格' from test1 where Name='宝马';
end;

