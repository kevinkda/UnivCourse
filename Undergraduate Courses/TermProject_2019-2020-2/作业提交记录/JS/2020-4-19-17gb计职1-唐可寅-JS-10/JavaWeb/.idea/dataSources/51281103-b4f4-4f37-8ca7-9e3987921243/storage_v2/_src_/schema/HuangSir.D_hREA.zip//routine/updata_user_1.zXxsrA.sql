create
    definer = cmrhyq@`%` procedure updata_user_1(IN user_ID int, IN userName varchar(32), IN userAge int)
begin
##delete from userTb where userID=user_ID; 
update userTb set userId=user_ID,userName=user_Name,userAge=user_Age;
end;

