create
    definer = cmrhyq@`%` procedure select_user()
begin
select * from userTb ; 
end;

