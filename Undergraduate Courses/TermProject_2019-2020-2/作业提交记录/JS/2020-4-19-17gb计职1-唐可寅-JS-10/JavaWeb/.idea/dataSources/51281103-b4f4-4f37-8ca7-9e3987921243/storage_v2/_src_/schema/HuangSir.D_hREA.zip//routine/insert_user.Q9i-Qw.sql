create
    definer = cmrhyq@`%` procedure insert_user(IN user_Name varchar(32), IN user_Age int)
begin
	insert  into  userTb (userId,userName,userAge) values(null,user_Name,user_Age);
	end;

