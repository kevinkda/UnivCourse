create
    definer = cmrhyq@`%` procedure delete_user_1(IN user_ID int)
begin
delete from userTb where userID=user_ID; 
end;

