create
    definer = cmrhyq@`%` procedure delete_user()
begin
delete from userTb where userId=33; 
end;

