$(function () {
    $("tr:even").css("background-color", "orange");
    $("tr:odd").css("background-color", "yellow");
});
