let script_foot = document.createElement("script");
script_foot.type = "text/javascript";
script_foot.src = "../../js/base/CrFixedBottom.js";
document.getElementsByTagName('head')[0].appendChild(script_foot);