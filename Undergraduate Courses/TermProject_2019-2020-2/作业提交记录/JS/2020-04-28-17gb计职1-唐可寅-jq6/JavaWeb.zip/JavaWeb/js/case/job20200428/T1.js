$(function () {
    $("ul li:even").css("color", "red");
});
