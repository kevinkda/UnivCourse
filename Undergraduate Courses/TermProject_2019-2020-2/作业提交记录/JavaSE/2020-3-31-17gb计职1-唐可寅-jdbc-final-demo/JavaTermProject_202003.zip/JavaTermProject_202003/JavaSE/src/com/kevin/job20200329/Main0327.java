package com.kevin.job20200329;

/**
 * @author Kevin KDA on 2020/3/26 12:42
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200329
 * @classname Main0327
 * @description
 * @interface/enum
 */
public class Main0327 {
    public static void main(String[] args) {
        new Control();
    }
}
