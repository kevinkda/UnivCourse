package com.kevin.job20200306.task2.entity;

import com.kevin.job20200306.task2.control.Factory;

/**
 * @author Kevin KDA on 2020/3/6 15:55
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200306.task2.entity
 * @classname Player
 * @description
 * @interface/enum
 */
public class Player extends Factory {

}
