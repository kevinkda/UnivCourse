package com.kevin.job20200325;

/**
 * @author Kevin KDA on 2020/3/25 16:42
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200325
 * @classname Main0325
 * @description
 * @interface/enum
 */
public class Main0325 {
    public static void main(String[] args) {
        new Control();
    }
}
