package com.kevin.job20200324;


/**
 * @author Kevin KDA on 2020/3/24 14:05
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200324
 * @classname Main0323
 * @description
 * @interface/enum
 */
public class Main0323 {
    public static void main(String[] args) {
        new Control();
    }
}
