package com.kevin.job20200331;

/**
 * @author Kevin KDA on 2020/3/31 20:25
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200331
 * @classname Main0331
 */
public class Main0331 {
    public static void main(String[] args) {
        new Control();
    }
}
