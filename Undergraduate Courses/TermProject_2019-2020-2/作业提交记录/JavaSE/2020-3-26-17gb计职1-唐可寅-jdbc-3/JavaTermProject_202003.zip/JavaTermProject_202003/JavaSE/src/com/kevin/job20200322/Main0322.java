package com.kevin.job20200322;


import com.kevin.job20200319.bookmanager.control.View;

/**
 * @author Kevin KDA on 2020/3/22 19:24
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200322
 * @classname Main0322
 * @description
 * @interface/enum
 */
public class Main0322 {
    public static void main(String[] args) {
        View view = new View();
    }
}
