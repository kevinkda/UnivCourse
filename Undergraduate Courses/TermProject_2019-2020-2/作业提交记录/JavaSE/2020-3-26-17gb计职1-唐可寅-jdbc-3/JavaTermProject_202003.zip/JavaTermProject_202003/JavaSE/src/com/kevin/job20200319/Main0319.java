package com.kevin.job20200319;


import com.kevin.job20200319.bookmanager.control.View;

/**
 * @author Kevin KDA on 2020/3/18 13:17
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200319
 * @classname Main0319
 * @description
 * @interface/enum
 */
public class Main0319 {
    public static void main(String[] args) {
        View view = new View();
    }
}
