package com.kevin.job20200326;

/**
 * @author Kevin KDA on 2020/3/26 12:42
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200326
 * @classname Main0326
 * @description
 * @interface/enum
 */
public class Main0326 {
    public static void main(String[] args) {
        new Control();
    }
}
