package com.kevin.job20200318.task1;

/**
 * @author Kevin KDA on 2020/3/17 13:15
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200318.task1
 * @classname Main0318T1
 * @description
 * @interface/enum
 */
public class Main0318T1 {
}
