package com.kevin.job20200318.task2;

/**
 * @author Kevin KDA on 2020/3/17 13:15
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200318.task2
 * @classname Main0318T2
 * @description
 * @interface/enum
 */
public class Main0318T2 {
}
