package com.kevin.job20200311.task1;

/**
 * @author Kevin KDA on 2020/3/11 15:55
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200311.task1
 * @classname Father
 * @description
 * @interface/enum
 */
public class Father {
    public void eat() {
        System.out.println("eat");
    }
}
