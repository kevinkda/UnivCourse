/*
 * Copyright (c) 2020 Kevin KDA. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.kevin.util.db;

import java.util.ResourceBundle;

/**
 * 提供页面分页服务
 *
 * @author Kevin KDA on 2020/3/29 20:48
 * @version 1.0
 * @package com.kevin.util.db
 * @classname PageBean
 */
public class PageBean {
    private static final int INT_DEFAULT_ITEMS_PER_PAGE;
    /**
     * 当前页面号
     */
    private int intPageCode;
    /**
     * 总页面数
     */
    private int intTotalPage;
    /**
     * 总记录数
     */
    private int intTotalRecord;
    /**
     * 每页记录数
     */
    private int intPageSize;

    /**
     * 分页数据上一页
     *
     * @return boolean 返回结果
     * @author Kevin KDA on 2020/3/29 20:46
     * @description PageBean / last
     */
    public boolean last() {
        if (intPageCode > 1) {
            intPageCode--;
            return true;
        } else {
            return false;
        }
    }

    /**
     * 分页数据下一页
     *
     * @return boolean 返回结果
     * @author Kevin KDA on 2020/3/29 20:46
     * @description PageBean / next
     */
    public boolean next() {
        if (intPageCode < intTotalRecord) {
            intPageCode++;
            return true;
        } else {
            return false;
        }
    }


    /*
     * 获得默认的每页记录数
     * @author Kevin KDA on 2020/3/29 19:39
     * @description PageBean / static
     */
    static {
        ResourceBundle resourceBundle = ResourceBundle.getBundle("com.kevin.util.resource.db.db");
        INT_DEFAULT_ITEMS_PER_PAGE = Integer.parseInt(resourceBundle.getString("jdbc.dataPaging.defaultItemsPerPage"));
    }

    public PageBean() {
        intPageCode = 1;
        intPageSize = INT_DEFAULT_ITEMS_PER_PAGE;
    }

    public PageBean(int intPageCode, int intTotalRecord, int intPageSize) {
        this.intPageCode = intPageCode;
        setIntTotalPage();
        this.intTotalRecord = intTotalRecord;
        this.intPageSize = intPageSize;
    }

    public int getIntPageCode() {
        return intPageCode;
    }

    public void setIntPageCode(int intPageCode) {
        this.intPageCode = intPageCode;
    }

    public int getIntTotalPage() {
        return intTotalPage;
    }

    public void setIntTotalPage() {
        int temp = intTotalRecord / intPageSize;
        this.intTotalPage = intTotalRecord % intPageSize == 0 ? temp : temp + 1;
    }

    public int getIntTotalRecord() {
        return intTotalRecord;
    }

    public void setIntTotalRecord(int intTotalRecord) {
        this.intTotalRecord = intTotalRecord;
    }

    public int getIntPageSize() {
        return intPageSize;
    }

    public void setIntPageSize(int intPageSize) {
        this.intPageSize = intPageSize;
    }
}
