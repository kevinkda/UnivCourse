create
    definer = kevin@`%` procedure NewProc(IN col1 varchar(20))
BEGIN
    #Routine body goes here...
    INSERT INTO table_name(column_2, column_3) VALUES (col1, col1);
    SELECT column_1, column_2, column_3 FROM table_name WHERE column_2 = col1;
END;

