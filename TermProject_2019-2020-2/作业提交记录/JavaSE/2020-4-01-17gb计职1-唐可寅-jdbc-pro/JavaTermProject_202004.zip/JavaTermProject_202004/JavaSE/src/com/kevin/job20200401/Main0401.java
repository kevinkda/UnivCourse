package com.kevin.job20200401;

/**
 * @author Kevin KDA on 2020/4/1 20:22
 * @version 1.0
 * @project JavaTermProject_202004
 * @package com.kevin.job20200401
 * @classname Main0401
 * @description
 * @interface/enum
 */
public class Main0401 {
    public static void main(String[] args) {
        new Control();
    }
}
