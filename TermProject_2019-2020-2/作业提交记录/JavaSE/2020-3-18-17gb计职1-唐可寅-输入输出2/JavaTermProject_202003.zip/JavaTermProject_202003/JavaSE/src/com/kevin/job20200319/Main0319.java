package com.kevin.job20200319;

/**
 * @author Kevin KDA on 2020/3/18 13:17
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200319
 * @classname Main0319
 * @description
 * @interface/enum
 */
public class Main0319 {
}
