package com.kevin.job20200310;

import com.kevin.job20200308.bookmanager.control.View;

/**
 * @author Kevin KDA on 2020/3/10 09:48
 * @version 1.0
 * @project JavaTermProject_202003
 * @package com.kevin.job20200310
 * @classname Main0310
 * @description
 * @interface/enum
 */
public class Main0310 {
    public static void main(String[] args) {
        View view = new View();
    }
}
