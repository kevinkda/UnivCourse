package com.kevin.job20200402;

/**
 * @author Kevin KDA on 2020/4/2 12:07
 * @version 1.0
 * @project JavaTermProject_202004
 * @package com.kevin.job20200402
 * @classname Main0402
 * @description
 * @interface/enum
 */
public class Main0402 {
    public static void main(String[] args) {
        new Control();
    }
}
