package com.kevinkda.test.domain;

/**
 * @author Kevin KDA on 2020/6/30 09:14
 * @version 1.0.0
 * @project maven-test-01
 * @package com.kevinkda.test.domain
 * @classname User
 * @apiNote <p></p>
 * @since 1.0.0
 */
public class User {

}
