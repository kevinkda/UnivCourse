package com.kevinkda.univ.course.web.test20200519.model;

/**
 * @author Kevin KDA on 2020/5/19 09:13
 * @version 1.0.0
 * @project JavaTermProject_202005
 * @package com.kevinkda.univ.course.web.test20200519.model
 * @classname User
 * @apiNote <p></p>
 * @since 1.0.0
 */
public class User {
}
