package com.kevinkda.univ.course.web.test20200519.dao.impl;

import com.kevinkda.univ.course.web.test20200519.dao.IUserDao;
import com.kevinkda.univ.course.web.test20200519.model.User;

import java.util.List;

/**
 * @author Kevin KDA on 2020/5/19 09:09
 * @version 1.0.0
 * @project JavaTermProject_202005
 * @package com.kevinkda.univ.course.web.test20200519.dao.impl
 * @classname UserDapImpl
 * @apiNote <p></p>
 * @since 1.0.0
 */
public class UserDapImpl implements IUserDao {
    @Override
    public List<User> selectUserList() {
        return null;
    }
}
