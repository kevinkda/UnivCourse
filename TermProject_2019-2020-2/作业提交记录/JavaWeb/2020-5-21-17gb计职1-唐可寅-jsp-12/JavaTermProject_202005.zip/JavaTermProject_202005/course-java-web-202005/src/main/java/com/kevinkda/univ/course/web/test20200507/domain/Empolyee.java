package com.kevinkda.univ.course.web.test20200507.domain;


/**
 * @author Kevin KDA on 2020/5/7 11:11
 * @version 1.0.0
 * @project JavaTermProject_202005
 * @package com.kevinkda.univ.course.test20200507.domain
 * @classname Empolyee
 * @apiNote <p></p>
 * @since 2020.05.07
 */
public class Empolyee {
    private int id;
    private String name;

    public Empolyee() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
