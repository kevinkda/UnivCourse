package com.kevinkda.univ.course.web.test20200511.servive;

import javax.servlet.http.HttpSession;

/**
 * @author Kevin KDA on 2020/5/11 09:56
 * @version 1.0.0
 * @project JavaTermProject_202005
 * @package com.kevinkda.univ.course.web.test20200511.servive
 * @classname ToolUtil
 * @apiNote <p></p>
 * @since 1.0.0
 */
public class ToolUtil {
    public static String sessionId;
}
