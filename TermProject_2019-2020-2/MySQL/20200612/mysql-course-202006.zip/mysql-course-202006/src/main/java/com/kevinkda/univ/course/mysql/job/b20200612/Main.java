package com.kevinkda.univ.course.mysql.job.b20200612;

import com.kevinkda.univ.course.mysql.job.b20200612.service.Control;

/**
 * @author Kevin KDA on 2020/6/11 18:53
 * @version 1.0.0
 * @project mysql-course-202006
 * @package com.kevinkda.univ.course.mysql.job.b20200612
 * @classname Main
 * @apiNote <p></p>
 * @since 2020.06.12
 */
public class Main {
    public static void main(String[] args) {
        Control control = new Control();
    }
}
